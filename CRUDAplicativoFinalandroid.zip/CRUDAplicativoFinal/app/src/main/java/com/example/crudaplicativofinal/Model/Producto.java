package com.example.crudaplicativofinal.Model;

public class Producto {

    private  int id;
    private String NombreProducto;
    private String descripcion;
    private double precio;
    private int stock;

    public String getNombreProducto() {
        return NombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        NombreProducto = nombreProducto;
    }

    public Producto(int i, String s, double v, int parseInt) {
    }

    public Producto(int id, String NombreProducto, String descripcion, double precio, int stock) {
        this.id = id;
        this.NombreProducto = NombreProducto;
        this.descripcion = descripcion;
        this.precio = precio;
        this.stock = stock;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return NombreProducto;
    }

    public void setName(String name) {
        this.NombreProducto= name;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
}
