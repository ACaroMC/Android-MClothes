package com.example.crudaplicativofinal.Activity;


import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;


import com.example.crudaplicativofinal.Model.Producto;
import com.example.crudaplicativofinal.R;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import com.example.crudaplicativofinal.API.ServiceAPI;
import com.example.crudaplicativofinal.Util.ConnectionREST;


import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity {


    private EditText etResultado;
    private EditText etid;
    private EditText NombreProducto;
    private EditText Precio;
    private EditText Stock;



    private ImageButton btncomprar;
    private  ImageButton btnEliminar;
    private ImageButton btnModificar;

    private ServiceAPI serviceAPI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etid = (EditText) findViewById(R.id.txtProducto);
        NombreProducto = (EditText) findViewById(R.id.txtdes);
        Precio = (EditText) findViewById(R.id.txtprecio);
        Stock = (EditText) findViewById(R.id.txtcategoria);
        etResultado= (EditText) findViewById(R.id.etResultado);


        btncomprar = (ImageButton) findViewById(R.id.btncomprar);
        btnEliminar = (ImageButton) findViewById(R.id.btnEliminar);
        btnModificar = (ImageButton) findViewById(R.id.btnModificar);

        
        serviceAPI = ConnectionREST.getConnection().create(ServiceAPI.class);

        load();

        btncomprar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Producto pObj = new Producto(Integer.parseInt(etid.getText().toString()),
                        NombreProducto.getText().toString(),
                        Double.parseDouble(Precio.getText().toString()),
                        Integer.parseInt(Stock.getText().toString())
                        );
                    addProducto(pObj);
            }
        });

        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                eliminarProducto(NombreProducto.getText().toString());}
        });

        btnModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Producto pObj = new Producto(Integer.parseInt(etid.getText().toString()),
                        NombreProducto.getText().toString(),
                        Double.parseDouble(Precio.getText().toString()),
                        Integer.parseInt(Stock.getText().toString()));
                        modificarProducto(pObj);
                   }


        });

    }

    private void eliminarProducto(String parseInt){
        Call<Producto> call = ServiceAPI.eliminarProducto(parseInt);
        call.enqueue(new Callback<Producto>() {
            @Override
            public void onResponse(Call<Producto> call, Response<Producto> response) {
                if (response.isSuccessful())
                {
                    mensaje("El producto se elimino correctamente !!");
                }
                else
                {
                    mensaje("Ocurrio un problema desconocido");
                }

            }

            @Override
            public void onFailure(Call<Producto> call, Throwable t) {
                mensaje("Ocurrio un error desconocido ... :C");

            }
        });
    }
    private void modificarProducto(Producto pObj){
        Call<Producto> call = ServiceAPI.modificarProducto(pObj);
        call.enqueue(new Callback<Producto>() {
            @Override
            public void onResponse(Call<Producto> call, Response<Producto> response) {
                if(response.isSuccessful())
                {
                    Producto pro = response.body();

                    mensaje("El producto se modifico satisfactoriamente!!!");
                }
                else
                {
                    mensaje("Ocurrio un error desconocido!!!");
                }

            }

            @Override
            public void onFailure(Call<Producto> call, Throwable t) {
                mensaje("Ocurrio un error desconocido!!!" + t.getMessage());
            }
        });
    }

        public void addProducto(Producto pObj)
        {
            Call<Producto> call = serviceAPI.addProducto(pObj);
            call.enqueue(new Callback<Producto>() {
                @Override
                public void onResponse(Call<Producto> call, Response<Producto> response) {
                    if(response.isSuccessful())
                    {

                        Producto pro = response.body();
                        mensaje("El producto se agregado correctamente!");
                    }
                    else
                    {
                        mensaje("Ocurrio un error al grabar los datos!");
                    }
                }

                @Override
                public void onFailure(Call<Producto> call, Throwable t) {

                }
            });
        }




    private void load() {
        Call<List<Producto>> call = serviceAPI.listProduct();
        call.enqueue(new Callback<List<Producto>>() {
            @Override
            public void onResponse(Call<List<Producto>> call, Response<List<Producto>> response) {
                if (response.isSuccessful())
                {
                    List<Producto> respuesta = response.body();
                    etResultado.setText("\n\n\n\n");
                    for(Producto x:respuesta)
                    {
                        etResultado.append("Id:" + x.getId()+ "Nombre:" + x.getNombreProducto() + "Precio" +  "Stock" + x.getStock() + "\n");
                        Toast.makeText(getApplicationContext(),"" + x.getDescripcion(), Toast.LENGTH_LONG).show();
                        mensaje(x.getId() + "-" + x.getDescripcion());
                    }
                }
                else
                {
                    Toast.makeText(null,"Error", Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<List<Producto>> call, Throwable t) {
                Toast.makeText(null,"Ocurrio un error", Toast.LENGTH_LONG).show();

            }
        });


    }
    public void mensaje(String msg)
    {
        AlertDialog.Builder alerta = new AlertDialog.Builder(this);
        alerta.setMessage(msg);
        alerta.show();
    }

}
