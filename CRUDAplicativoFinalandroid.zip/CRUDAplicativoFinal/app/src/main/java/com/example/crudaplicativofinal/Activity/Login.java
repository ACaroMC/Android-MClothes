package com.example.crudaplicativofinal.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.app.AlertDialog;


import com.example.crudaplicativofinal.R;
import androidx.appcompat.app.AppCompatActivity;

public class Login  extends AppCompatActivity {

    public Login(EditText txtUsuario, EditText txtPass, Button btnlogin) {
        this.txtUsuario = txtUsuario;
        this.txtPass = txtPass;
        this.btnlogin = btnlogin;
    }
    private EditText txtUsuario;
    private EditText txtPass;

    private Button btnlogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {




        super.onCreate(savedInstanceState);
        setContentView(R.layout.loginmc);
        txtUsuario = (EditText) findViewById(R.id.etUsuario);
        txtPass = (EditText) findViewById(R.id.etPass);
        btnlogin = (Button) findViewById(R.id.btnLogin);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtUsuario.getText().toString().isEmpty() || txtPass.getText().toString().isEmpty()) {
                    alertaRechazo("Usuario/Contraseña no pueden estar vacíos");
                } else {
                    if (txtUsuario.getText().toString().equals("admin") && String.valueOf(txtPass.getText()).equals("admin")) {
                        alertaIngreso("Bienvenido al Sistema");
                        final Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                Intent i = new Intent(Login.this, MainActivity.class);
                                startActivity(i);
                            }
                        }, 4000);
                    } else {
                        alertaRechazo("Usuario o Contraseña incorrecta. ");
                    }
                }
            }
        });
      }

     public void alertaRechazo(String cadena) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setMessage(cadena);
        dialogBuilder.setCancelable(true).setTitle("Credenciales incorrectas");
        dialogBuilder.create().show();
     }

     public void alertaIngreso(String cadena) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setMessage(cadena);
        dialogBuilder.setCancelable(true).setTitle("!BIENVENIDO A MC CLOTHES!");
        dialogBuilder.create().show();
     }



}
