package com.example.crudaplicativofinal.API;
import com.example.crudaplicativofinal.Model.Producto;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;





public interface ServiceAPI {
    @GET("producto")
    public abstract Call<List<Producto>> listProduct();

    @POST("producto/agregar")
    public abstract Call<Producto> addProducto(@Body Producto obj);

    @PUT("producto/modificar")
    public static Call<Producto> modificarProducto(@Body Producto obj) {
        return null;
    }


    @DELETE("producto/eliminar/{id}")
    public static Call<Producto> eliminarProducto(@Path("id") String id) {
        return null;
    }


}
